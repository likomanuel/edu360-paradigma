# edu360-paradigma
El Paradigma EDU360, el Sistema SRAA, la arquitectura EDU360 v10 y la Matriz de Rigor  asociada constituyen una obra intelectual original desarrollada por el Creador del  Paradigma. Su finalidad es establecer una infraestructura formal, replicable y verificable  para una educación
